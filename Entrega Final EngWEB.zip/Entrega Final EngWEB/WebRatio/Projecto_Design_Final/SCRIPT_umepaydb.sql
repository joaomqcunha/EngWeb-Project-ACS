-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 19/01/2012 às 00h19min
-- Versão do Servidor: 5.5.16
-- Versão do PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `umepaydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `carregamentos`
--

CREATE TABLE IF NOT EXISTS `carregamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` date DEFAULT NULL,
  `montante` double DEFAULT NULL,
  `pre_saldo` double DEFAULT NULL,
  `pos_saldo` double DEFAULT NULL,
  `user_oid` int(11) DEFAULT NULL,
  `tiposcarregamentos_id_tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_carregamentos_user` (`user_oid`),
  KEY `fk_carregamentos_tiposcarregam` (`tiposcarregamentos_id_tipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `carregamentos`
--

INSERT INTO `carregamentos` (`id`, `data`, `montante`, `pre_saldo`, `pos_saldo`, `user_oid`, `tiposcarregamentos_id_tipo`) VALUES
(1, '2012-01-18', 10, 0, 10, 1, 1),
(2, '2012-01-18', 15, 10, 25, 1, 2),
(3, '2012-01-18', 20, 0, 20, 2, 2),
(4, '2012-01-18', 50, 0, 50, 6, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `comprassenhas`
--

CREATE TABLE IF NOT EXISTS `comprassenhas` (
  `id` int(11) NOT NULL,
  `pre_saldo` double DEFAULT NULL,
  `pos_saldo` double DEFAULT NULL,
  `data_compra` date DEFAULT NULL,
  `user_oid` int(11) DEFAULT NULL,
  `tipossenhas_id_tipo` int(11) DEFAULT NULL,
  `data_senha` date DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comprassenhas_user` (`user_oid`),
  KEY `fk_comprassenhas_tipossenhas` (`tipossenhas_id_tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `comprassenhas`
--

INSERT INTO `comprassenhas` (`id`, `pre_saldo`, `pos_saldo`, `data_compra`, `user_oid`, `tipossenhas_id_tipo`, `data_senha`, `quantidade`) VALUES
(1, 25, 5, '2012-01-18', 1, 1, '2012-01-18', 8),
(2, 20, 17.55, '2012-01-18', 2, 1, NULL, 1),
(3, 17.55, 15.100000000000001, '2012-01-18', 2, 1, '2012-01-18', 0),
(4, 50, 30, '2012-01-18', 6, 1, '2012-01-18', 8),
(5, 30, 27.55, '2012-01-18', 6, 1, '2012-01-18', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `faturas`
--

CREATE TABLE IF NOT EXISTS `faturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) DEFAULT NULL,
  `montate` double DEFAULT NULL,
  `data` timestamp NULL DEFAULT NULL,
  `user_oid` int(11) DEFAULT NULL,
  `user_oid_2` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_faturas_user` (`user_oid`),
  KEY `fk_faturas_user_2` (`user_oid_2`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Extraindo dados da tabela `faturas`
--

INSERT INTO `faturas` (`id`, `descricao`, `montate`, `data`, `user_oid`, `user_oid_2`) VALUES
(1, 'croissant queijo', 0.8, '2012-01-18 00:00:00', 0, 1),
(2, 'leite achocolatado', 0.5, '2012-01-18 00:00:00', 0, 2),
(3, 'torrada', 1, '2012-01-18 00:00:00', 0, 2),
(4, 'chiclet', 0.1, '2012-01-18 00:00:00', 0, 2),
(5, 'croissant misto', 1.2, '2012-01-18 00:00:00', 4, 6),
(6, 'santal', 0.8, '2012-01-18 00:00:00', 4, 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `oid` int(11) NOT NULL,
  `groupname` varchar(255) DEFAULT NULL,
  `module_oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`oid`),
  KEY `fk_group_module` (`module_oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `group`
--

INSERT INTO `group` (`oid`, `groupname`, `module_oid`) VALUES
(0, 'Funcionários', 0),
(1, 'Alunos', 1),
(3, 'Administradores', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `group_module`
--

CREATE TABLE IF NOT EXISTS `group_module` (
  `group_oid` int(11) NOT NULL,
  `module_oid` int(11) NOT NULL,
  PRIMARY KEY (`group_oid`,`module_oid`),
  KEY `fk_group_module_group` (`group_oid`),
  KEY `fk_group_module_module` (`module_oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `group_module`
--

INSERT INTO `group_module` (`group_oid`, `module_oid`) VALUES
(0, 0),
(1, 1),
(3, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `lang`
--

CREATE TABLE IF NOT EXISTS `lang` (
  `oid` int(11) NOT NULL,
  `lang` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `linguagem` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `lang`
--

INSERT INTO `lang` (`oid`, `lang`, `country`, `linguagem`) VALUES
(0, 'en', 'GB', 'Inglês'),
(1, 'pt', 'PT', 'Português');

-- --------------------------------------------------------

--
-- Estrutura da tabela `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `oid` int(11) NOT NULL,
  `moduleid` varchar(255) DEFAULT NULL,
  `modulename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `module`
--

INSERT INTO `module` (`oid`, `moduleid`, `modulename`) VALUES
(0, 'sv3', 'Funcionário'),
(1, 'sv2', 'Aluno'),
(3, 'sv5', 'Admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tiposcarregamentos`
--

CREATE TABLE IF NOT EXISTS `tiposcarregamentos` (
  `id_tipo` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tiposcarregamentos`
--

INSERT INTO `tiposcarregamentos` (`id_tipo`, `descricao`) VALUES
(1, 'Multibanco'),
(2, 'Cartao de crédito');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipossenhas`
--

CREATE TABLE IF NOT EXISTS `tipossenhas` (
  `id_tipo` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `preco` double DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `quantidade_tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tipossenhas`
--

INSERT INTO `tipossenhas` (`id_tipo`, `descricao`, `preco`, `tipo`, `quantidade_tipo`) VALUES
(1, 'Pack de 10 senhas com desconto', 20, 'Pack', 10),
(2, 'Senha Individual para cantina', 2.45, 'Individual', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `oid` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `local` varchar(255) DEFAULT NULL,
  `nif` int(11) DEFAULT NULL,
  `idioma` varchar(255) DEFAULT NULL,
  `fotografia` varchar(255) DEFAULT NULL,
  `saldo` double DEFAULT NULL,
  `senhas` int(11) DEFAULT NULL,
  `group_oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`oid`),
  KEY `fk_user_group` (`group_oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`oid`, `username`, `password`, `email`, `local`, `nif`, `idioma`, `fotografia`, `saldo`, `senhas`, `group_oid`) VALUES
(0, 'F123', 'pass123', 'F123@umepay.pt', 'CP1', NULL, 'GB', NULL, NULL, 0, 0),
(1, 'PG19812', '19812', 'PG19812@umepay.pt', '', 12345, 'PT', 'http://joaomqcunha.droppages.com/site/eu.jpg', 4.2, 0, 1),
(2, 'PG19807', '19807', 'PG19812@umepay.pt', '', 12345, 'PT', 'http://m3.licdn.com/mpr/mpr/shrink_100_100/p/1/000/0c6/342/3fd25f1.jpg', 13.5, 0, 1),
(3, 'PG18932', '18932', 'PG18932@umepay.pt', NULL, 12345, 'GB', '', 0, 0, 1),
(4, 'F98765', '98765', 'F98765@umepay.pt', 'CP2', 12345, 'PT', NULL, 0, 0, 0),
(5, 'AdminUMePay', 'adminpass', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3),
(6, 'A55900', '55900', 'A55900@umepay.pt', '', 12345, 'PT', 'http://a4.sphotos.ak.fbcdn.net/hphotos-ak-snc7/300908_178998162182535_100002170582819_361713_4926917_n.jpg', 25.55, 0, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `user_oid` int(11) NOT NULL,
  `group_oid` int(11) NOT NULL,
  PRIMARY KEY (`user_oid`,`group_oid`),
  KEY `fk_user_group_user` (`user_oid`),
  KEY `fk_user_group_group` (`group_oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `user_group`
--

INSERT INTO `user_group` (`user_oid`, `group_oid`) VALUES
(0, 0),
(1, 1),
(2, 1),
(3, 1),
(4, 0),
(5, 3),
(6, 1);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `carregamentos`
--
ALTER TABLE `carregamentos`
  ADD CONSTRAINT `fk_carregamentos_tiposcarregam` FOREIGN KEY (`tiposcarregamentos_id_tipo`) REFERENCES `tiposcarregamentos` (`id_tipo`),
  ADD CONSTRAINT `fk_carregamentos_user` FOREIGN KEY (`user_oid`) REFERENCES `user` (`oid`);

--
-- Restrições para a tabela `comprassenhas`
--
ALTER TABLE `comprassenhas`
  ADD CONSTRAINT `fk_comprassenhas_tipossenhas` FOREIGN KEY (`tipossenhas_id_tipo`) REFERENCES `tipossenhas` (`id_tipo`),
  ADD CONSTRAINT `fk_comprassenhas_user` FOREIGN KEY (`user_oid`) REFERENCES `user` (`oid`);

--
-- Restrições para a tabela `faturas`
--
ALTER TABLE `faturas`
  ADD CONSTRAINT `fk_faturas_user` FOREIGN KEY (`user_oid`) REFERENCES `user` (`oid`),
  ADD CONSTRAINT `fk_faturas_user_2` FOREIGN KEY (`user_oid_2`) REFERENCES `user` (`oid`);

--
-- Restrições para a tabela `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `fk_group_module` FOREIGN KEY (`module_oid`) REFERENCES `module` (`oid`);

--
-- Restrições para a tabela `group_module`
--
ALTER TABLE `group_module`
  ADD CONSTRAINT `fk_group_module_group` FOREIGN KEY (`group_oid`) REFERENCES `group` (`oid`),
  ADD CONSTRAINT `fk_group_module_module` FOREIGN KEY (`module_oid`) REFERENCES `module` (`oid`);

--
-- Restrições para a tabela `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_group` FOREIGN KEY (`group_oid`) REFERENCES `group` (`oid`);

--
-- Restrições para a tabela `user_group`
--
ALTER TABLE `user_group`
  ADD CONSTRAINT `fk_user_group_group` FOREIGN KEY (`group_oid`) REFERENCES `group` (`oid`),
  ADD CONSTRAINT `fk_user_group_user` FOREIGN KEY (`user_oid`) REFERENCES `user` (`oid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
