<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Compra de Senha
        </title>
    </head>
    <body>
    	<div id="site">
            <? 
                include("includes/header2.php"); 
                include("includes/senhasAlunoAJAX.php"); 
            ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="senhas.php"><?php echo $lang_senhas_menu0 ?></a></li></br>
                </div>
                <div id ="corpo" align="center">
                    <h2><?php echo $lang_senhas_title0?></h2>
                    <br>
                    <table id="listagem">
                        <tr>
                            <th><?php echo $lang_senhas_lista0?></th>
                            <th><?php echo $lang_senhas_lista1?></th>
                            <th><?php echo $lang_senhas_lista2?></th>
                            <th><?php echo $lang_senhas_lista3?></th>
                            <th></th>
                        </tr>
                        <?
                            $result = getTiposSenhas();
                            while($row = mysql_fetch_array($result)) {
                                echo '<tr>';
                                    echo '<td>'.$row['id_tipo'].'</td>';
                                    echo '<td>'.$row['tipo'].'</td>';
                                    echo '<td>'.$row['descricao'].'</td>';
                                    echo '<td>'.$row['preco'].'</td>';
                                    echo '<td><input type="submit" value="Comprar" onclick="comprarSenha('.$row['id_tipo'].')"/></td>';
                                echo '</tr>';
                            }
                        ?>
                    </table><br><br>
                    <div id="showCompra" align="center"></div>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
        </div>
        <? include("includes/footer.php"); ?>
    </body>
</html>