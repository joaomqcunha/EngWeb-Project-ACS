<?php
    include("includes/sess_conn.php");
    
    if(isset($_GET['id'])) $id = $_GET['id'];
    else $id = "F";
?>
<html>
    <head>
    <? 
        include("includes/header.php");
        include("includes/consultasAlunoAJAX.php");
    ?>
        <title>
            UM-ePay - Consultas
        </title>
    </head>
    <body>
    	<div id="site">
            <? 
                include("includes/header2.php");
                include("includes/consultasAlunoAJAX.php");
            ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="consultas.php?id=F">Faturas</a></li>
                    <?
                        if($_SESSION['group'] == 1) {
                            echo '<li><a href="consultas.php?id=S">Senhas</a></li>';
                            echo '<li><a href="consultas.php?id=C">Carregamentos</a></li>';
                        }
                    ?>
                </div>
                <div id ="corpo">
                    <br>
                    <div id="lista">
                        <?
                            if($id == "F") {
                                if($_SESSION['group'] == 1) $result = getFaturas($_SESSION['user']);
                                else $result = getFaturasFunc($_SESSION['user']);
                                if(mysql_num_rows($result) > 0) {
                                    echo '<h2>Lista de Faturas</h2>';
                                    echo '<table id="listagem">';
                                        echo '<tr>';
                                            echo '<th>ID</th>';
                                            echo '<th>Descrição</th>';
                                            echo '<th></th>';
                                        echo '</tr>';
                                        while($row = mysql_fetch_array($result)) {
                                            echo '<tr>';
                                                echo '<td>'.$row['id'].'</td>';
                                                echo '<td>'.$row['descricao'].'</td>';
                                                echo '<td><input type="submit" value="Detalhes" onclick="showDetailsFatura('.$row['id'].')" /></td>';
                                            echo '</tr>';
                                        }
                                    echo '</table>';
                                }
                                else {
                                    echo '<h3>Não foram encontradas Faturas</h3>';
                                }
                            }
                            else if($id == "S") {
                                $result = getSenhas($_SESSION['user']); 
                                if(mysql_num_rows($result) > 0) {
                                    echo '<h2>Lista de Senhas</h2>';
                                    echo '<table id="listagem">';
                                        echo '<tr>';
                                            echo '<th>ID</th>';
                                            echo '<th>Data de Compra</th>';
                                            echo '<th>Estado</th>';
                                            echo '<th></th>';
                                        echo '</tr>';
                                        while($row = mysql_fetch_array($result)) {
                                            echo '<tr>';
                                                echo '<td>'.$row['id'].'</td>';
                                                echo '<td>'.$row['data_compra'].'</td>';
                                                if($row['quantidade'] == 0) echo '<td>Esgotado(a)</td>';
                                                else if($row['tipo'] == "Pack" && $row['quantidade'] != 10) echo '<td>Utilizado('.(10-$row['quantidade']).')</td>';
                                                else echo '<td>Por Utilizar</td>';
                                                echo '<td><input type="submit" value="Detalhes" onclick="showDetailsSenhas('.$row['id'].')" /></td>';
                                            echo '</tr>';
                                        }
                                    echo '</table>';
                                }
                                else {
                                    echo '<h3>Não foram encontradas Senhas</h3>';
                                }
                            }
                            else if($id == "C") {
                                $result = getCarregamentos($_SESSION['user']); 
                                if(mysql_num_rows($result) > 0) {
                                    echo '<h2>Lista de Carregamentos</h2>';
                                    echo '<table id="listagem">';
                                        echo '<tr>';
                                            echo '<th>ID</th>';
                                            echo '<th>Data</th>';
                                             echo '<th></th>';
                                        echo '</tr>';
                                        while($row = mysql_fetch_array($result)) {
                                            echo '<tr>';
                                                echo '<td>'.$row['id'].'</td>';
                                                echo '<td>'.$row['data'].'</td>';
                                                echo '<td><input type="submit" value="Detalhes" onclick="showDetailsCarregamento('.$row['id'].')" /></td>';
                                            echo '</tr>';
                                        }
                                    echo '</table>';
                                }
                                else {
                                    echo '<h3>Não foram feitos Carregamentos</h3>';
                                }
                            }
                        ?>
                    </div>
                    <div id="showDetails"></div>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
        </div>
        <? include("includes/footer.php"); ?>
    </body>
</html>