<?php

    include("includes/sess_conn.php");


    if(isset($_POST['email']) && isset($_POST['pass']) && isset($_SESSION['user'])) {
        
        if (isset($_FILES['foto'])) {
            if ($_FILES["foto"]["size"] > 0) {

                move_uploaded_file($_FILES["foto"]["tmp_name"], "images/" . $_FILES["foto"]["name"]);

                $foto = 'images/'. $_FILES["foto"]["name"];
            }
        }
        
        if(isset($foto)) $query = 'UPDATE user SET email="' . $_POST['email'] . '", nif="' . $_POST['nif'] . '", password="' . $_POST['pass'] . '", fotografia="images/' . $_FILES["foto"]["name"] . '" WHERE oid=' . $_SESSION['user'];
        else if(isset($_POST['nif'])) $query = 'UPDATE user SET email="'.$_POST['email']. '", nif="'.$_POST['nif']. '", password="'.$_POST['pass'].'" WHERE oid='.$_SESSION['user'];
        else $query = 'UPDATE user SET email="'.$_POST['email']. '", password="'.$_POST['pass'].'" WHERE oid='.$_SESSION['user'];
        
        mysql_query($query) or die(mysql_error());
                
    }
    else header("location:javascript:index.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Atualizar Dados
        </title>
    </head>
    <body>
    	<div id="site">
            <? 
                include("includes/header2.php");
            ?>
            <div id="content">
                <div id ="leftmenu">
                    <br>
                </div>
                <div id ="corpo" align="center">
                    <p><h2><?php echo $lang_atualizar_title0 ?></h2></p>
                    <p><a href="conta.php"><?php echo $lang_atualizar_title1?></a></p>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
        </div>
        <? include("includes/footer.php"); ?>
    </body>
</html>