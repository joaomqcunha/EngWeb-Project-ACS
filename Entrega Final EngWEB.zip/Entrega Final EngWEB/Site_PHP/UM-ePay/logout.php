<?php
    include('includes/sess_conn.php');
    session_destroy();
    header('location:index.php');
?>
