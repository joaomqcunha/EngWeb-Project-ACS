<?php

    include("includes/sess_conn.php");

    $q=$_POST["valor"];
    $p=$_POST["desc"];
    $z=$_POST["id"];
    
    $pre_saldo;
    $pos_saldo;

    $row = getUser($z);
    
    $pre_saldo = $row['saldo'];
    $pos_saldo = $pre_saldo - $q;
    
    if($pos_saldo >=0) {
        mysql_query("UPDATE user SET saldo = '".$pos_saldo."' WHERE oid = '".$z."'");
        mysql_query("INSERT INTO faturas (descricao, montante, data, user_oid, user_oid_2) VALUES ('".$p."', ".$q.", now(), ".$_SESSION['user'].", ".$z.")");  

        $suc = 1;
    }
    else $suc = 0;
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Compra Efetuada
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <br>
                </div>
                <div id ="corpo">
                    <?
                        if($suc == 1) {
                            echo '<p><h2 align="center">Compra efectuada com sucesso</h2></p>';
                        }
                        else {
                            echo '<p><h2 align="center">Utilizador não tem saldo suficiente para concluir a operação!</h2></p>';
                        }
                    ?>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>