<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
    <? include("includes/js_functions.php"); ?>
        <title>
            UM-ePay - Administração
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="admin.php"><?php echo $lang_admin_title0 ?></a></li></br>
                </div>
                <div id ="corpo">
                    <h1><?php echo $lang_admin_title1?></h1>
                    <form>
                        <div><h3><?php echo $lang_admin_title2?></h3></div>
                        <select name="users" onchange="sendIDUser(this.value)">
                            <option value=""><?php echo $lang_admin_select?></option>
                                <?php
                                    $sql="SELECT * FROM user";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result)){
                                        echo "<option value=\"" . $row['oid'] . "\"";
                                        echo ">";
                                        echo $row['username'];
                                        echo "</option>";
                                    }
                                ?>
                        </select>
                         
                    </form>
                    <div id="txtHint"><h4><?php echo $lang_admin_title3?> </h4></div>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>