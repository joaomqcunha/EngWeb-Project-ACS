<?php
    require_once("includes/sess_conn.php");    
    if(isset($_GET['cal'])) $cal = $_GET['cal'];
    else $cal = 1;
    
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
       
        <title>
            UM-ePay - Home
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="index.php?cal=1"><?php echo $lang_leftmenu0 ?></a></li></br>
                    <li><a href="index.php?cal=2"><?php echo $lang_leftmenu1 ?></a></li></br>
                    <li><a href="index.php?cal=3"><?php echo $lang_leftmenu2 ?></a></li></br>
                    <li><a href="index.php?cal=4"><?php echo $lang_leftmenu3 ?></a></li></br>
                </div>
                <div id ="corpo">
                    <?
                        switch ($cal) {
                            case 1:
                                include('includes/cal_1.php');
                                break;
                            case 2:
                                include('includes/cal_2.php');
                                break;
                            case 3:
                                include('includes/cal_3.php');
                                break;
                            case 4:
                                include('includes/cal_4.php');
                                break;
                        }
                    ?>
                    <br><br><br>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>
