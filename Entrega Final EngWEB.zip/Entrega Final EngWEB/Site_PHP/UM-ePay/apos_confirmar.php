<?php
    
    include("includes/sess_conn.php");

    $q=$_POST["id"];

    $result2 = mysql_query("UPDATE comprassenhas SET quantidade = quantidade-1, data_senha = now() WHERE id = '".$q."'");
    
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Confirmação de Entrada
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="cantina.php">Cantina</a></li></br>
                </div>
                <div id ="corpo">
                    <?
                        echo '<p><h2 align="center">Senha descontada com sucesso!</h2></p>';
                    ?>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>