<?php

    include("includes/sess_conn.php");

    if(isset($_POST['user']) && isset($_POST['pass'])) {
    
        $user = $_POST['user'];
        $pass = $_POST['pass'];

        $query = "SELECT g.oid as gro, u.oid as usern FROM user u, `group` g WHERE u.group_oid = g.oid AND u.username='".$user."' AND u.password='".$pass."'";

        $res = mysql_query($query, $conn);
        
        if(mysql_num_rows($res) > 0) {
            $row = mysql_fetch_array($res);
            $_SESSION['user'] = $row['usern'];
            $_SESSION['group'] = $row['gro'];
            
            echo '<meta http-equiv="refresh" content="2; url=index.php">';
        }
    }
    else header("location:javasript:index.php");

?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Login
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="index.php?cal=1"><?php echo $lang_leftmenu0 ?></a></li></br>
                    <li><a href="index.php?cal=2"><?php echo $lang_leftmenu1 ?></a></li></br>
                    <li><a href="index.php?cal=3"><?php echo $lang_leftmenu2 ?></a></li></br>
                    <li><a href="index.php?cal=4"><?php echo $lang_leftmenu3 ?></a></li></br>
                </div>
                <div id ="corpo">
                    <? 
                        if(isset ($_SESSION['user'])) {
                            echo '<div style="text-align:center"><p><h2>'.$lang_aposlogin0.'</h2></p>';
                            echo '<p><a href="index.php?">'.$lang_aposlogin1.'</a></p></div>';
                        }
                        else {
                            echo '<div style="text-align:center"><p><h2>'.$lang_aposlogin2.'</h2></p><p>'.$lang_aposlogin3.'</p></div>';
                        }
                    ?>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>