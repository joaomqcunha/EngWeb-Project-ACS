<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <?php include("includes/js_functions.php")?>
        <title>
            UM-ePay - Carregamento
        </title>
    </head>
    <body>
    	<div id="site">
            <? 
                include("includes/header2.php");
                include("includes/carregamentoAlunoAJAX.php");
            ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="carregamentos.php">Carregamentos</a></li></br>
                </div>
                <div id ="corpo" align="center">
                    <p><h2>Efetuar Carregamento</h2></p>
                    <br>
                    <form name="carregamento" id="form_carregamento" action="apos_carregamento.php" method="POST" onsubmit="return validarForm(this);">
                        <table>
                            <tr>
                                <td id="label" style="text-align:right">Montante:</td>
                                <td style="text-align: left">
                                    <input type="text" name="in_valor" size="2" style="text-align: right" onkeyup="limparErro()"/>€
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td style="color:red"><div id="erroValor"></div></td>
                            </tr>
                            <tr>
                                <td id="label"></td>
                                <td style="text-align: left">
                                    <select name="tipo" onchange="showFormsCarregamento(this.value)">
                                        <?php
                                        echo "<option value=\"999\">Selecionar:</option>";
                                            $result=getTiposCarregamento();
                                            while($row = mysql_fetch_array($result)) {
                                                echo '<option value="'.$row['id_tipo'].'">'.$row['descricao'].'</option>';
                                            }
                                        ?>
                                    </select>
                                    <div id="txtHint">Selecione uma opção por favor. </div>
                                </td>
                            </tr>
                        </table>
                        <p><input type="submit" value="Carregar"/></p>
                    </form>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
        </div>
        <? include("includes/footer.php"); ?>
    </body>
</html>