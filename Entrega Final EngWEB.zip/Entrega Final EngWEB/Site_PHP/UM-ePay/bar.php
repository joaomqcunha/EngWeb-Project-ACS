<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Compra no Bar
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="bar.php">Bar</a></li></br>
                </div>
                <script type="text/javascript">
                    function showHint(str)
                    {
                    if (str.length==0)
                      { 
                      document.getElementById("txtHint").innerHTML="";
                      return;
                      }
                    if (window.XMLHttpRequest)
                      {// code for IE7+, Firefox, Chrome, Opera, Safari
                      xmlhttp=new XMLHttpRequest();
                      }
                    else
                      {// code for IE6, IE5
                      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                      }
                    xmlhttp.onreadystatechange=function()
                      {
                      if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                        document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                        }
                      }
                    xmlhttp.open("GET","includes/makeBuy.php?q="+str,true);
                    xmlhttp.send();
                    }
                </script>              
                
                <div id ="corpo">
                    <p><h2 align="center"><?php echo $lang_bar_title0 ?></h2></p>
                    <form id="gethint2" onsubmit="return false;">
                        <?php echo $lang_bar_title1?><input type="text" onkeyup="showHint(this.value)" >
                    </form>
                    
                    <div id="txtHint"></div>
                    
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>