<?php

    include("includes/sess_conn.php");

    if(isset($_POST['in_valor']) && isset($_POST['tipo']) && isset($_SESSION['user'])) {
        $user = getUser($_SESSION['user']);
        $val = $_POST['in_valor'];
        
        $saldoAtual = ($user['saldo']+$val);
        
        if($_POST['tipo']=='2') $query = 'INSERT INTO carregamentos (data,montante,pre_saldo,pos_saldo,user_oid,tiposcarregamentos_id_tipo,titular,cartao,num_cartao,mes_venc,ano_venc,cvv) VALUES (NOW(),'.$val.','.$user['saldo'].','.$saldoAtual.','.$user['oid'].','.$_POST['tipo'].',\''.$_POST['nomeTitular'].'\',\''.$_POST['selectTipo'].'\',\''.$_POST['ncartao'].'\',\''.$_POST['mv'].'\',\''.$_POST['av'].'\',\''.$_POST['cvv'].'\')';
        else $query = 'INSERT INTO carregamentos (data,montante,pre_saldo,pos_saldo,user_oid,tiposcarregamentos_id_tipo,email_pp) VALUES (NOW(),'.$val.','.$user['saldo'].','.$saldoAtual.','.$user['oid'].','.$_POST['tipo'].',\''.$_POST['mail'].'\')';
        mysql_query($query);
        
        $query = 'UPDATE user SET saldo='.$saldoAtual.' WHERE oid='.$user['oid'];
        
        mysql_query($query);
    }
    else header("location:javascript:index.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Carregamento de Conta
        </title>
    </head>
    <body>
    	<div id="site">
            <? 
                include("includes/header2.php");
                include("includes/carregamentoAlunoAJAX.php");
            ?>
            <div id="content">
                <div id ="leftmenu">
                    <br>
                </div>
                <div id ="corpo" align="center">
                    <p><h2>Carregamento Efectuado com sucesso</h2></p>
                    <p>O seu saldo actual é de: <? echo $saldoAtual; ?></p>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
        </div>
        <? include("includes/footer.php"); ?>
    </body>
</html>