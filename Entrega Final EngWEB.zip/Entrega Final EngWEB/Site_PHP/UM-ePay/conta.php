<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
    <? include("includes/js_functions.php"); ?>
        <title>
            UM-ePay - Conta Pessoal
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="conta.php"><?php echo $lang_conta_menu0 ?></a></li></br>
                    <li><a href="atualizar.php"><?php echo $lang_conta_menu1 ?></a></li></br>
                </div>
                <div id ="corpo" align="center">
                    <?
                        $row = getUser($_SESSION['user']);
                        echo '<h2>'.$lang_conta_title0.'</h2>';
                        echo '<br><table>';
                            echo '<tr>
                                <td align="right"><b>ID:</b></td>
                                <td align="left">'. $row['oid'] .'</td>
                            </tr>
                            <tr>
                                <td align="right"><b>Username:</b></td>
                                <td align="left">'. $row['username'] .'</td>
                            </tr>
                            <tr>
                                <td align="right"><b>E-Mail:</b></td>
                                <td align="left">'. $row['email'] .'</td>
                            </tr>';
                            if ($_SESSION['group'] == 0){
                                echo '<tr>
                                    <td align="right"><b>Local:</b></td>
                                    <td align="left">'. $row['local'] .'</td>
                                </tr>';
                            }
                            if ($_SESSION['group'] == 1) {
                                echo '<tr>
                                    <td align="right"><b>NIF:</b></td>
                                    <td align="left">'. $row['nif'] .'</td>
                                </tr>';
                                echo '<tr>
                                        <td align="right"><b>Imagem:</b></td>
                                        <td align="left"><img src="'. $row['fotografia'] .'" height=250 width=200/></td>';
                                echo '</tr>';
                            }
                        echo "</table>";
                    ?>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>