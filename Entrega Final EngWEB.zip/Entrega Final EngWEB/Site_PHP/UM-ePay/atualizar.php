<?php
    include("includes/sess_conn.php");
?>
<html>
    <head>
    <? include("includes/header.php"); ?>
        <title>
            UM-ePay - Atualizar Dados
        </title>
    </head>
    <body>
    	<div id="site">
            <? include("includes/header2.php"); ?>
            <div id="content">
                <div id ="leftmenu">
                    <li><a href="conta.php"><?php echo $lang_conta_menu0 ?></a></li></br>
                    <li><a href="atualizar.php"><?php echo $lang_conta_menu1 ?></a></li></br>
                </div>

                <div id ="corpo" align="center">
                    <p><h2><?php echo $lang_conta_title1 ?></h2></p>
                    <br>
                    <form id="form_atualizar_dados" action="apos_atualizar.php" method="POST" enctype="multipart/form-data">
                        <table>
                            <?php $info = getUser($_SESSION['user']);?>
                            
                            <tr>
                                <td style="text-align: right">ID:</td>
                                <td style="text-align: left">
                                    <?php 
                                    echo '<input type="text" name="id" disabled value="'.$info['oid'].'" size="15"/>' ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="text-align: right">Username:</td>
                                <td style="text-align: left">
                                    <?php 
                                    echo '<input type="text" name="username" disabled value="'.$info['username'].'"  size="15"/>' ?>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right">E-Mail:</td>
                                <td style="text-align: left">
                                    <?php 
                                        echo '<input type="text" name="email" value="'.$info['email'].'"  size="30"/>'
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right">Password:</td>
                                <td style="text-align: left">
                                    <?php 
                                        echo '<input type="password" name="pass" value="'.$info['password'].'" size="15"/>'
                                    ?>
                                </td>
                            </tr>
                            <?
                                if($_SESSION['group'] == 0) {
                                    echo '<tr>
                                        <td style="text-align: right">Local:</td>
                                        <td style="text-align: left">
                                            <input type="text" name="local" disabled value="'.$info['local'].'"  size="15"/>
                                        </td>
                                    </tr>';
                                }
                                if($_SESSION['group'] == 1) {
                                    echo '<tr>
                                        <td style="text-align: right">NIF:</td>
                                        <td style="text-align: left">
                                            <input type="text" name="nif" value="'.$info['nif'].'"  size="15"/>
                                        </td>
                                    </tr>';
                                    echo '<tr>
                                        <td style="text-align: right">Foto:</td>
                                        <td style="text-align: left">
                                                <img src="'. $info['fotografia'] .'" height=250 width=200/><br>
                                                        Alterar:<input type="file" name="foto"/>

                                        </td>
                                    </tr>';
                                }
                            ?>
                            <tr>
                                <td></td>
                                <td style="text-align: right">
                                    <input type="submit" value="Atualizar"/>
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
                <? include("includes/rightmenu.php"); ?>
            </div>
            <? include("includes/footer.php"); ?>
        </div>
    </body>
</html>