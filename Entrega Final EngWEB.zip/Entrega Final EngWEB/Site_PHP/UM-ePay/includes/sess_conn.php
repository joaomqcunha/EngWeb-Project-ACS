<?php
    
    session_start();
    
    $conn = mysql_connect("localhost", "root", "root");
    if(!$conn) {
        die('Não conseguiu conectar'. mysql_error());
    }
    
    mysql_select_db("umepaydb", $conn);
    mysql_set_charset('utf8');
    
    include('functions.php');
    
    error_reporting(E_ALL);
    ini_set('display_errors', '1');

    if (!isset($_SESSION['lang'])) $_SESSION['lang'] = "PT";
    
    include('lang_'. $_SESSION['lang'].'.php');
?>
