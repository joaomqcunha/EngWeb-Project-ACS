<?php

    include("sess_conn.php");
    
    //get the q parameter from URL
    $q=$_GET["q"];
    
    $result = mysql_query("SELECT * FROM user WHERE group_oid = 1 AND username='".$q."'");

    if($row = mysql_fetch_array($result)) {
        $pre_saldo=$row['saldo'];
        echo "<br />";
        echo "<br />";
        echo '<div id="lista"><img src="'.$row['fotografia'].'" height=250 width=200></div>';
        echo '<div id="showDetails">';
        echo "<form id=\"gethint\" method=\"post\" action=\"apos_compra.php\">";
            echo '<table>';
                echo '<tr><td style="text-align:right">Valor: </td><td style="text-align:left"><input type="text" name="valor" ></td></tr>';
                echo '<tr><td style="text-align:right">Descricao: </td><td style="text-align:left"><input type="text" name="desc" ></td>';
                echo '<tr><td></td><td style="text-align:right"><input type="submit" value="Efectuar Compra"></td></tr>';
            echo '</table>';
            echo '<input type="text" name="id" value="'.$row['oid'].'" style="visibility: hidden">';
        echo "</form>";
        echo '</div>';
    }
    else echo '<br><br>[Não existe nenhum utilizador com esse username]';

?>

