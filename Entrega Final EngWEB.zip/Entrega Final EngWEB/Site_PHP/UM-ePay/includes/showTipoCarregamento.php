<?php
include("sess_conn.php");
$id = $_GET["q"];
if ($id==2){
    include("cartaoCredito.php");
}else if ($id==3){
    echo '<form method="POST">';
    echo '<br/>';
    echo 'Email da sua conta do PayPal: <input type="text" name="mail" size="30" required autofocus/><br />';
    echo '</form>';
}else
    echo "Selecione uma opÃ§Ã£o por favor.";
?>
