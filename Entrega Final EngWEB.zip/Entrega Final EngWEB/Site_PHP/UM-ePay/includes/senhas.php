<?php
    
    include("sess_conn.php");
    $id=$_GET["q"];
    
    $result = getSenhas($id);
   
    echo "<h3>Senhas</h3>";
    while ($row = mysql_fetch_array($result)){
        echo '<details>
            <summary>ID: '.$row['id'].' Data: '.$row['data_compra'].'</summary>';
         echo ' <b>- Data de Compra:</b> '. $row['data_compra'] .'<br>
                <b>- Tipo:</b> '. $row['tipo'] .'<br>';
                if($row['tipossenhas_id_tipo'] == 1) {
                    if($row['quantidade'] == 0) {
                        echo '<b>- Estado:</b> Esgostado<br>';
                        echo '<b>- Última Utilização:</b> '. $row['data_senha'] .'<br>';
                    }
                    else if($row['quantidade'] == 10) echo '<b>- Estado:</b> Por Utilizar<br>';
                    else {
                        echo '<b>- Estado:</b> Utilizadas('.(10-$row['quantidade']).')<br>';
                        echo '<b>- Última Utilização:</b> '. $row['data_senha'] .'<br>';
                    }
                }
                else {
                    if($row['quantidade'] == 0) {
                        echo '<b>- Estado:</b> Esgostada<br>';
                        echo '<b>- Utilização:</b> '. $row['data_senha'] .'<br>';
                    }
                    else {
                        echo '<b>- Estado:</b> Por Utilizar<br>';
                    }
                }
                echo '<b>- Pré-Saldo:</b> '. $row['pre_saldo'] .'<br>
                <b>- Pos-Saldo:</b> '. $row['pos_saldo'] .'<br>';
          echo '</details>';
    }
    
   
    echo "<div class=\"buttons\">";
    echo '<button type=\"button" class="voltar" onclick=sendIDUser('.$id.')><img src="http://icons.iconarchive.com/icons/custom-icon-design/pretty-office-5/256/go-back-icon.png">Voltar</button>';
    echo "</div>";
    
    mysql_close();
?>
