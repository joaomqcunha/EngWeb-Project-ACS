<?php

    include("sess_conn.php");

    //get the q parameter from URL
    $q=$_GET["q"];


    $result = mysql_query("SELECT * FROM user WHERE group_oid = 1 AND username='".$q."'");

    if($row = mysql_fetch_array($result)) {
        $user_oid=$row['oid'];
        echo "<br />";
        echo "<br />";
        echo '<div id="lista"><img src="'.$row['fotografia'].'" height=250 width=200></div>';
        echo '<br><br>';
    
        $result2 = mysql_query("SELECT * FROM comprassenhas WHERE quantidade>0 AND user_oid='".$user_oid."'");
        
        echo '<div id="showDetails">';
        
            if($row = mysql_fetch_array($result2)) {
                
                echo '<form name="senhas_form" method="post" action="apos_confirmar.php">';
                    echo '<input type="text" name="id" value="'.$row['id'].'" style="visibility: hidden"><br>';
                    echo '<input type="submit" value="Confirmar Entrada">';
                echo "</form>";
            }
            else echo '[O utilizador não tem senhas]';
            
        echo '</div>';    
    }
    else echo '<br><br>[Não existe nenhum utilizador com esse username]';
    
    mysql_close($conn);
?>
