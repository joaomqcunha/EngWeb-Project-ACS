<?php
require("sess_conn.php");
$q = $_GET['l'];
$_SESSION['lang'] = $q;
header("location: ../".$_GET['p']);
?>
