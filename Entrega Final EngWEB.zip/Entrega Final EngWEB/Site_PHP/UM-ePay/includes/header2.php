<? include("includes/firstHeader.php"); ?>
<div id="sheader">
    <div id ="banner">
        <div id="logo">
        </div>
        <div id="title">
        <h1><?php echo $lang_title ?></h1>
        </div>
    </div>
    <? include("includes/login.php"); ?>
</div>
