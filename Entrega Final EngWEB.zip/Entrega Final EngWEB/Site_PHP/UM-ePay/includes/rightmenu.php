<?php
    echo '<div id ="rightmenu">';
        echo '<div id="pub"><img src="images/logoUM.jpg" width="140px"></br></div><br><br>';
        echo '<div id="pub"><img src="images/paypal.png" width="140px"></br></div><br><br>';
        echo '<div id="pub"><img src="images/VisaMastercardLOGO.jpg" width="140px"></br></div>';
    echo '</div>';
?>
