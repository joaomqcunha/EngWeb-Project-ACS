<?php
    include("sess_conn.php");
    $id=$_GET["q"];
    
    $result = getCarregamentos($id);
   
    echo "<h3>Carregamentos</h3>";
    while ($row = mysql_fetch_array($result)){
        echo '<details>
            <summary>ID: '.$row['id'].' Data: '.$row['data'].'</summary>';
        echo '  <b>- Montante:</b> '.$row['montante'].'<br>
                <b>- Tipo:</b> '. $row['descricao'] .'<br>
                <b>- Pré-Saldo:</b> '. $row['pre_saldo'] .'<br>
                <b>- Pos-Saldo:</b> '. $row['pos_saldo'] .'<br>';
        echo '</details>';
    }
    echo "<div class=\"buttons\">";
    echo '<button type=\"button" class="voltar" onclick=sendIDUser('.$id.')><img src="http://icons.iconarchive.com/icons/custom-icon-design/pretty-office-5/256/go-back-icon.png">Voltar</button>';
    echo "</div>";
    mysql_close();
?>
