<?php
    include('sess_conn.php');


    $q=$_GET["q"];
    if ($q==""){
        echo "Selecione um utilizador.";
    }else{
    $row = getUser($q);
    echo '<br><table>';
        echo '<tr>
            <td align="right"><b>ID:</b></td>
            <td align="left">'. $row['oid'] .'</td>
        </tr>
        <tr>
            <td align="right"><b>Username:</b></td>
            <td align="left">'. $row['username'] .'</td>
        </tr>
        <tr>
            <td align="right"><b>E-Mail:</b></td>
            <td align="left">'. $row['email'] .'</td>
        </tr>';
        if($row['group_oid']==1) {
            echo '<tr>
                <td align="right"><b>NIF:</b></td>
                <td align="left">'. $row['nif'] .'</td>
            </tr>';
        }
        echo '<tr>
            <td align="right"><b>Grupo:</b></td>
            <td align="left">'. $row['group_oid'] .'</td>
        </tr>';
    echo "</table>";
    echo "<div class=\"buttons\">";
    if($row['group_oid'] == 1) {
        echo "<button type=\"button\" class=\"carregamentos\" onclick=\"verCarregamentos(".$q.")\"><img src=\"http://icons.iconarchive.com/icons/aha-soft/standard-portfolio/256/Money-icon.png\">Carregamentos</button>";
        echo "<button type=\"button\" class=\"pagamentos\" onclick=\"verSenhas(".$q.")\"><img src=\"http://images2.wikia.nocookie.net/__cb20100628124721/ztreasureisle/images/6/62/Island_Cash-icon.png\">Senhas</button>";
    }
    
    echo "<button type=\"button\" onclick=\"verFaturas(".$q.")\">Faturas</button>";
    echo "</div>";
    }
?>
