<div id="login">
    <?
        if(!isset($_SESSION['user'])) {
            echo '<form method="POST" action="apos_login.php">';
                echo '<br/>';
                echo $lang_loginuser.': <input type="text" name="user" size="9"  placeholder="Username da UM" required autofocus/><br />';
                echo $lang_loginpass.': <input type="password" name="pass" size="9" placeholder="Insira a senha." required autofocus/><br />';
                echo '<input type="submit" value="'.$lang_loginbutton.'" />';
            echo '</form>';
        }
        else{
            $user = getUser($_SESSION['user']);
            echo '<br>';
            echo '<table align="center">';
                echo '<tr>';
                    echo '<td style="text-align: right">';
                        echo '<b>'.$lang_loginuser.':</b>';
                    echo '</td>';
                    echo '<td style="text-align: left">';
                        echo $user['username'];
                    echo '</td>';
                echo '</tr>';
                if($_SESSION['group'] == 1) {
                    echo '<tr>';
                        echo '<td style="text-align: right">';
                            echo '<b>'.$lang_loginsaldo.':</b>';
                        echo '</td>';
                        echo '<td style="text-align: left">';
                            echo $user['saldo']." €";
                        echo '</td>';
                    echo '</tr>';
                }
                else if($_SESSION['group'] == 0) {
                    echo '<tr>';
                        echo '<td style="text-align: right">';
                            echo '<b>'.$lang_loginlocal.':</b>';
                        echo '</td>';
                        echo '<td style="text-align: left">';
                            echo $user['local'];
                        echo '</td>';
                    echo '</tr>';
                }
            echo '</table>';
            echo '<h3><a href="logout.php">'.$lang_loginlogout.'</a></h3>';
        }
     ?>
</div>