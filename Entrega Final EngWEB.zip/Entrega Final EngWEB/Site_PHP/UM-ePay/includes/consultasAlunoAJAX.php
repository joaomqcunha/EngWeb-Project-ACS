<script type="text/javascript">
    function getHTTPObject(){
       if (window.ActiveXObject) 
           return new ActiveXObject("Microsoft.XMLHTTP");
       else if (window.XMLHttpRequest) 
           return new XMLHttpRequest();
       else {
          alert("Your browser does not support AJAX.");
          return null;
       }
    }

    /*
    function altEmp(emp){
        if (emp=="") {
            document.getElementById("empArea").innerHTML="";
            return;
        }
        httpObject = getHTTPObject();
        if (httpObject != null) {
            httpObject.onreadystatechange=function() {
                if (httpObject.readyState==4 && httpObject.status==200) {
                    document.getElementById("empArea").innerHTML=httpObject.responseText;
                }
            }
            httpObject.open("GET","includes/ajaxRegistoPHP.php?emp="+emp, true);
            httpObject.send();
        }
    }
    */

    function showDetailsFatura(f) {
        if (f=="") {
            document.getElementById("showDetails").innerHTML="";
            return;
        }
        httpObject = getHTTPObject();
        if (httpObject != null) {
            httpObject.onreadystatechange=function() {
                if (httpObject.readyState==4 && httpObject.status==200) {
                    document.getElementById("showDetails").innerHTML=httpObject.responseText;
                }
            }
            httpObject.open("GET","includes/consultasAluno.php?fat="+f, true);
            httpObject.send();
        }
    }
    
    function showDetailsSenhas(f) {
        if (f=="") {
            document.getElementById("showDetails").innerHTML="";
            return;
        }
        httpObject = getHTTPObject();
        if (httpObject != null) {
            httpObject.onreadystatechange=function() {
                if (httpObject.readyState==4 && httpObject.status==200) {
                    document.getElementById("showDetails").innerHTML=httpObject.responseText;
                }
            }
            httpObject.open("GET","includes/consultasAluno.php?senha="+f, true);
            httpObject.send();
        }
    }
    
    function showDetailsCarregamento(f) {
        if (f=="") {
            document.getElementById("showDetails").innerHTML="";
            return;
        }
        httpObject = getHTTPObject();
        if (httpObject != null) {
            httpObject.onreadystatechange=function() {
                if (httpObject.readyState==4 && httpObject.status==200) {
                    document.getElementById("showDetails").innerHTML=httpObject.responseText;
                }
            }
            httpObject.open("GET","includes/consultasAluno.php?car="+f, true);
            httpObject.send();
        }
    }
    
</script>
