<?

    function getFaturas($id) {
        $query = "SELECT * FROM faturas WHERE user_oid_2=".$id;
        return mysql_query($query);
    }
    
    function getFaturasFunc($id) {
        $query = "SELECT * FROM faturas WHERE user_oid=".$id;
        return mysql_query($query);
    }
    
    function getFatura($id) {
        $query = "SELECT * FROM faturas WHERE id=".$id;
        return mysql_query($query);
    }

    function getSenhas($id) {
        $query = "SELECT s.*, t.tipo, t.preco FROM comprassenhas s, tipossenhas t WHERE t.id_tipo = s.tipossenhas_id_tipo AND s.user_oid=".$id." ORDER BY data_compra";
        return mysql_query($query);
    }
    
    function getSenha($id) {
        $query = "SELECT s.*, t.tipo, t.preco FROM comprassenhas s, tipossenhas t WHERE t.id_tipo = s.tipossenhas_id_tipo AND id=".$id;
        $result = mysql_query($query);
        return mysql_fetch_array($result);
    }
    
    function getCarregamentos($id) {
        $query = "SELECT c.*, t.descricao FROM carregamentos c, tiposcarregamentos t WHERE t.id_tipo = c.tiposcarregamentos_id_tipo AND c.user_oid=".$id." ORDER BY data";
        return mysql_query($query);
    }
    
    function getCarregamento($id) {
        $query = "SELECT c.*, t.descricao FROM carregamentos c, tiposcarregamentos t WHERE t.id_tipo = c.tiposcarregamentos_id_tipo AND c.id=".$id;
        return mysql_query($query);
    }
    
    function getTiposSenhas() {
        $query = "SELECT * FROM tipossenhas";
        return mysql_query($query);
    }
    
    function getTipoSenha($id) {
        $query = "SELECT * FROM tipossenhas WHERE id_tipo=".$id;
        $result = mysql_query($query);
        return mysql_fetch_array($result);
    }
    
    function getUser($id){
        $query = "SELECT * FROM user WHERE oid=".$id;
        $result = mysql_query($query);
        return mysql_fetch_array($result);
    }
    
    function getTiposCarregamento() {
        $query = "SELECT * FROM tiposcarregamentos";
        return mysql_query($query);
    }
    
?>