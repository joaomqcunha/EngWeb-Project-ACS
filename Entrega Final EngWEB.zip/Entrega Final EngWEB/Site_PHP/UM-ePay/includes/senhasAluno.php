<?php

    include("sess_conn.php");

    if(isset($_GET['senha'])) {
        
        $user = getUser($_SESSION['user']);
        $senha = getTipoSenha($_GET['senha']);
                        
        if(($user['saldo'] - $senha['preco']) > 0) {
            
            $query = 'INSERT INTO comprassenhas (pre_saldo,pos_saldo,data_compra,user_oid,tipossenhas_id_tipo,quantidade) VALUES ('.$user['saldo'].','.($user['saldo'] - $senha['preco']).',NOW(),'
                        .$user['oid'].','.$senha['id_tipo'].','.$senha['quantidade_tipo'].')';
            
            mysql_query($query);
            
            $query="UPDATE user SET saldo=".($user['saldo'] - $senha['preco'])." WHERE oid=".$user['oid'];
            mysql_query($query);
            
            
            echo '<h2>'.$lang_senhas_error0Senha.'</h2>';
            echo $lang_senhas_error1Senha.($user['saldo'] - $senha['preco']).' €';
        }
        else {
            echo '<h2>'.$lang_senhas_error2.'</h2>';
            echo $lang_senhas_error3;
        }
    }
?>
