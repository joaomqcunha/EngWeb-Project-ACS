<script type="text/javascript">
    
   var progressBar = document.getElementById('progress');
  function updateProgress(newValue) {
    progressBar.textContent = newValue;
  }
 <!--<p>Progress: <progress> <span id="progress">0</span>% </progress> </p>-->    

  
    function browsersAndDivDefault(str){
        if (str==""){
            document.getElementById("txtHint").innerHTML="";
            return;
        } 
        if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        }
        else{// code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
            if (xmlhttp.readyState==4 && xmlhttp.status==200){
                document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
            }
        }
    }
    
    function sendIDUser(str){
        browsersAndDivDefault(str);
        xmlhttp.open("GET","includes/getUser.php?q="+str,true);
        xmlhttp.send();
    }
  
     function verCarregamentos(str){
         browsersAndDivDefault(str);
         xmlhttp.open("GET","includes/carregamentos.php?q="+str,true);
         xmlhttp.send();
     }
     
     function verSenhas(str){
         browsersAndDivDefault(str);
         xmlhttp.open("GET","includes/senhas.php?q="+str,true);
         xmlhttp.send();
     }
     
     function verFaturas(str){
         browsersAndDivDefault(str);
         xmlhttp.open("GET","includes/faturas.php?q="+str,true);
         xmlhttp.send();
     }
     
     function showFormsCarregamento(str){
         browsersAndDivDefault(str);
         xmlhttp.open("GET","includes/showTipoCarregamento.php?q="+str,true);
         xmlhttp.send();
     }
     
</script>
