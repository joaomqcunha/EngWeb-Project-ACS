<?php
$lang_title = 'UM-ePay: Sistema de Pagamentos Online';

$lang_loginuser = "Utilizador";
$lang_loginsaldo = "Saldo";
$lang_loginlocal = "Local";
$lang_loginbutton = "Iniciar Sessão";
$lang_loginlogout = "Terminar Sessão";
$lang_loginpass = "Senha";

$lang_aposlogin0 = "Início de Sessão efetuado com sucesso!";
$lang_aposlogin1 = "Ir para página inicial.";
$lang_aposlogin2 = "Inicío de sessão falhou!";
$lang_aposlogin3 = "Tente novamente.";

$lang_topmenu0 = "Página Inicial";
$lang_topmenu1 = "Conta Pessoal";
$lang_topmenu2 = "Consultas";
$lang_topmenu3 = "Bar";
$lang_topmenu4 = "Cantina";
$lang_topmenu5 = "Senhas";
$lang_topmenu6 = "Carregamentos";
$lang_topmenu7 = "Administração";

$lang_leftmenu0 = "Almoço";
$lang_leftmenu1 = "Almoço Vegetariano";
$lang_leftmenu2 = "Jantar";
$lang_leftmenu3 = "Jantar Vegetariano";

$lang_copyright = "Trabalho realizado por";

$lang_title_page0 = "Ementa para Almoço na Cantina";
$lang_title_page1 = "Ementa para Almoço Vegetariano na Cantina";
$lang_title_page2 = "Ementa para Jantar na Cantina";
$lang_title_page3 = "Ementa para Jantar Vegetariano na Cantina";

$lang_conta_title0 = "Informação do Utilizador";
$lang_conta_title1 = "Atualizar Informação Pessoal";
$lang_conta_menu0 ="Conta Pessoal";
$lang_conta_menu1 ="Atualizar Dados";

$lang_senhas_menu0 = "Senhas";
$lang_senhas_title0 = "Compra de Senhas da Cantina";
$lang_senhas_lista0="ID";
$lang_senhas_lista1="Tipo";
$lang_senhas_lista2="Descrição";
$lang_senhas_lista3="Preço";

$lang_senhas_error0="Senha comprada com sucesso";
$lang_senhas_error1="O seu saldo actual é de: ";
$lang_senhas_error2="Saldo Insuficiente";
$lang_senhas_error3="Carregue a sua conta!";

$lang_bar_title0 = "Efectuar Compra";
$lang_bar_title1 = "Número de Aluno(username): ";

$lang_cantina_title0 = "Cantina";
$lang_cantina_title1 = "Entrada na Cantina";

$lang_admin_title0 = "Utilizadores";
$lang_admin_title1 = "Consultar";
$lang_admin_title2 = "Lista de Utilizadores:";
$lang_admin_title3 = "[Selecione um utilizador para ver a sua informação]";
$lang_admin_select = "Selecionar:";

$lang_atualizar_title0 = "Alteração efectuada com sucesso";
$lang_atualizar_title1 = "Voltar para conta pessoal";
?>
