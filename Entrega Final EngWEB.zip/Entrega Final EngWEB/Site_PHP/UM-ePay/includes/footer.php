<div id="footer">
   <b> <?php echo $lang_copyright ?>: </b> João Cunha, Carlos Martins e Ricardo Gomes;
</div>
