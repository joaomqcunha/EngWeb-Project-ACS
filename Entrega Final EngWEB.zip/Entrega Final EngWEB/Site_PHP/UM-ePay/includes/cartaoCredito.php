<?php
    echo "<br/>";
    echo "<form method=\"POST\">";
    echo "<tr>
            <td id=\"label2\" style=\"text-align:right\">Nome do Titular:</td>
            <td style=\"text-align: left\">
                <input type=\"text\" name=\"nomeTitular\" size=\"35\" style=\"text-align: right\"/>
            </td>
          </tr>";
    echo "<br/>";
    echo "<tr>
            <td id=\"label3\" style=\"text-align:right\">Cartão:</td>
            <td style=\"text-align: left\">
            <select name=\"selectTipo\">
                <option value=\"1\"> MasterCard </option>
                <option value=\"2\"> Visa </option>
              </select>
              </td>
          </tr>";
    echo "<br/>";
    echo "<tr>
              <td id=\"label4\" style=\"text-align:right\">Nº Cartão:</td>
              <td style=\"text-align: left\">
                <input type=\"text\" name=\"ncartao\" size=\"4\" style=\"text-align: right\" onkeyup=\"limparErro()\"/>
              </td>
           </tr>";
     echo "<br/>";
     echo "<tr>
              <td id=\"label5\" style=\"text-align:right\">Mês Venc.</td>
              <td style=\"text-align: left\">
                <input type=\"text\" name=\"mv\" size=\"2\" style=\"text-align: right\" onkeyup=\"limparErro()\"/>
              </td>
              <td id=\"label6\" style=\"text-align:right\">Ano Venc.</td>
              <td style=\"text-align: left\">
                <input type=\"text\" name=\"av\" size=\"2\" style=\"text-align: right\" onkeyup=\"limparErro()\"/>
              </td>
              <td id=\"label7\" style=\"text-align:right\">CVV.</td>
              <td style=\"text-align: left\">
                <input type=\"text\" name=\"cvv\" size=\"2\" style=\"text-align: right\" onkeyup=\"limparErro()\"/>
              </td>
           </tr>";
     echo "</form>";
?>
