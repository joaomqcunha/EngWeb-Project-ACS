<?php
    include("sess_conn.php");
    $id=$_GET["q"];
    
    $row2 = getUser($id);
    
    if($row2['group_oid'] == 0) {
        $result = getFaturasFunc($id);
    }
    else $result = getFaturas ($id);
   
    echo "<h3>Faturas</h3>";
    while ($row = mysql_fetch_array($result)){
        echo '<details>
            <summary>ID: '.$row['id'].' Data: '.$row['data'].'</summary>';
        echo '  <b>- Montante:</b> '.$row['montante'].'<br>
                <b>- Descrição:</b> '. $row['descricao'] .'<br>';
                if($row2['group_oid'] == 1) {
                    $row3 = getUser($row['user_oid']);
                    echo '<b>- Funcionário:</b> '. $row3['username'] .'<br>';
                }
                else {
                    $row3 = getUser($row['user_oid_2']);
                    echo '<b>- Aluno:</b> '. $row3['username'] .'<br>';
                }
        echo '</details>';
    }
    
   
    echo "<div class=\"buttons\">";
    echo '<button type=\"button" class="voltar" onclick=sendIDUser('.$id.')><img src="http://icons.iconarchive.com/icons/custom-icon-design/pretty-office-5/256/go-back-icon.png">Voltar</button>';
    echo "</div>";
    
    mysql_close();
?>