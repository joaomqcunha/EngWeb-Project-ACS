<?
    echo '<h1>'.$lang_title_page1.'</h1></br>';
    echo '<iframe src="https://www.google.com/calendar/embed?title=Ementa%20para%20Almo%C3%A7o%20na%20Cantina&amp;showTitle=0&amp;showTabs=0&amp;showCalendars=0&amp;height=500&amp;wkst=2&amp;hl=pt_PT&amp;bgcolor=%23FFFFFF&amp;src=o1n262ugsh3tg96jn6t75f8fnc%40group.calendar.google.com&amp;color=%235229A3&amp;ctz=Europe%2FLisbon" style=" border-width:0 " width="600" height="500" frameborder="0" scrolling="no"></iframe>';
?>   
