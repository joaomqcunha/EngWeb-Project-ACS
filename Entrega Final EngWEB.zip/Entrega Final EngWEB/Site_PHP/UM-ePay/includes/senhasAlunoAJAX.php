<script type="text/javascript">
    function getHTTPObject(){
       if (window.ActiveXObject) 
           return new ActiveXObject("Microsoft.XMLHTTP");
       else if (window.XMLHttpRequest) 
           return new XMLHttpRequest();
       else {
          alert("Your browser does not support AJAX.");
          return null;
       }
    }

    function comprarSenha(f) {
        if (f=="") {
            document.getElementById("showCompra").innerHTML="";
            return;
        }
        httpObject = getHTTPObject();
        if (httpObject != null) {
            httpObject.onreadystatechange=function() {
                if (httpObject.readyState==4 && httpObject.status==200) {
                    document.getElementById("showCompra").innerHTML=httpObject.responseText;
                }
            }
            httpObject.open("GET","includes/senhasAluno.php?senha="+f, true);
            httpObject.send();
        }
    }
    
</script>
