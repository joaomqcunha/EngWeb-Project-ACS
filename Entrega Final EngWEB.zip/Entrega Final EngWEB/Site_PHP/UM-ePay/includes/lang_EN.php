<?php
$lang_title = 'UM-ePay: Online Payment System'; 

$lang_loginuser = "User";
$lang_loginsaldo = "Ammount";
$lang_loginlocal = "Place";
$lang_loginbutton = "Login";
$lang_loginlogout = "logout";
$lang_loginpass = "Password";

$lang_aposlogin0 = "Sucess!";
$lang_aposlogin1 = "Go home or wait 3 seconds...";
$lang_aposlogin2 = "Login incorrect...";
$lang_aposlogin3 = "Try again.";

$lang_topmenu0 = "Home";
$lang_topmenu1 = "My Account";
$lang_topmenu2 = "Consult";
$lang_topmenu3 = "Bar";
$lang_topmenu4 = "Refectory";
$lang_topmenu5 = "Tickets";
$lang_topmenu6 = "Deposits";
$lang_topmenu7 = "Management";

$lang_leftmenu0 = "Lunch";
$lang_leftmenu1 = "Vegetarian lunch";
$lang_leftmenu2 = "Dinner";
$lang_leftmenu3 = "Vegetarian Dinner";

$lang_copyright = "by";

$lang_title_page0 = "Lunch Menu";
$lang_title_page1 = "Menu Vegetarian Lunch";
$lang_title_page2 = "Menu Dinner";
$lang_title_page3 = "Menu Vegetarian Dinner";

$lang_conta_title0 = "User Details";
$lang_conta_title1 = "Update Personal Data";
$lang_conta_menu0 ="My Account";
$lang_conta_menu1 ="Update Details";

$lang_senhas_menu0 = "Senhas";
$lang_senhas_title0 = "Compra de Senhas da Cantina";
$lang_senhas_lista0="ID";
$lang_senhas_lista1="Tipo";
$lang_senhas_lista2="Descrição";
$lang_senhas_lista3="Preço";

$lang_senhas_error0="Senha comprada com sucesso";
$lang_senhas_error1="O seu saldo actual é de: ";
$lang_senhas_error2="Saldo Insuficiente";
$lang_senhas_error3="Carregue a sua conta!";

$lang_bar_title0 = "Efectuar Compra";
$lang_bar_title1 = "Número de Aluno(username): ";

$lang_cantina_title0 = "Refectory";
$lang_cantina_title1 = "Refectory entry";

$lang_admin_title0 = "Users";
$lang_admin_title1 = "Consult";
$lang_admin_title2 = "List of users:";
$lang_admin_title3 = "[Select user]";
$lang_admin_select = "Select:";

$lang_atualizar_title0 = "Sucess!";
$lang_atualizar_title1 = "Back to my account.";
?>
?>
