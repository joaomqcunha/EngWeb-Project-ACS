<script type="text/javascript">
    function getHTTPObject(){
       if (window.ActiveXObject) 
           return new ActiveXObject("Microsoft.XMLHTTP");
       else if (window.XMLHttpRequest) 
           return new XMLHttpRequest();
       else {
          alert("Your browser does not support AJAX.");
          return null;
       }
    }
    
    function isNumber(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }

    function validarForm(form){
        var val = form['in_valor'].value;
        if(isNumber(val)) return true;
        else {
            document.getElementById("erroValor").innerHTML='<i>Valor tem que ser numérico</i>';
            return false;
        }
    }
    
    function limparErro() {
        document.getElementById("erroValor").innerHTML="";
    }
    
</script>