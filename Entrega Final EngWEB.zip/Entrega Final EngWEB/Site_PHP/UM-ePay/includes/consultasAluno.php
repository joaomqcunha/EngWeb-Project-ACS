<?php

    include("sess_conn.php");

    if(isset($_GET['fat'])) {
        $id = $_GET['fat'];
        $result = getFatura($id);
        $row = mysql_fetch_array($result);
        echo '<table>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">ID:</td>';
                echo '<td style="text-align: left">';
                    echo $row['id'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Descrição:</td>';
                echo '<td style="text-align: left">';
                    echo $row['descricao'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Montante:</td>';
                echo '<td style="text-align: left">';
                    echo $row['montante'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Data:</td>';
                echo '<td style="text-align: left">';
                    echo $row['data'];
                echo '</td>';
            echo '</tr>';
            
            if($_SESSION['group'] == 1) {
                echo '<tr>';
                    echo '<td id="label" style="text-align:right">Funcionário:</td>';
                    echo '<td style="text-align: left">';
                        $u = getUser($row['user_oid']);
                        echo $u['username'];
                    echo '</td>';
                echo '</tr>';
            }
            else {
                echo '<tr>';
                    echo '<td id="label" style="text-align:right">Aluno:</td>';
                    echo '<td style="text-align: left">';
                        $u = getUser($row['user_oid_2']);
                        echo $u['username'];
                    echo '</td>';
                echo '</tr>';
            }
        echo '</table>';
    }
    else if(isset($_GET['senha'])) {
        $id = $_GET['senha'];
        $row = getSenha($id);
        echo '<table>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">ID:</td>';
                echo '<td style="text-align: left">';
                    echo $row['id'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Compra:</td>';
                echo '<td style="text-align: left">';
                    echo $row['data_compra'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Tipo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['tipo'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Pré-Saldo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['pre_saldo'].' €';
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Pós-Saldo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['pos_saldo'].' €';
                echo '</td>';
            echo '</tr>';
            if( is_null($row['data_senha']) == false) {
                echo '<tr>';
                    if($row['tipo'] == "Pack") {
                        echo '<td id="label" style="text-align:right">Última Utilização:</td>';
                    }
                    else {
                        echo '<td id="label" style="text-align:right">Utilização:</td>';
                    }
                    echo '<td style="text-align: left">';
                        echo $row['data_senha'];
                    echo '</td>';
                echo '</tr>';
            }
            if( $row['quantidade'] > 1) {
                echo '<tr>';
                    echo '<td id="label" style="text-align:right">Unidades:</td>';
                    echo '<td style="text-align: left">';
                        echo $row['quantidade'];
                    echo '</td>';
                echo '</tr>';
            }
        echo '</table>';
    }
    else if(isset($_GET['car'])) {
        $id = $_GET['car'];
        $result = getCarregamento($id);
        $row = mysql_fetch_array($result);
        echo '<table>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">ID:</td>';
                echo '<td style="text-align: left">';
                    echo $row['id'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Data:</td>';
                echo '<td style="text-align: left">';
                    echo $row['data'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Tipo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['descricao'];
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Montante:</td>';
                echo '<td style="text-align: left">';
                    echo $row['montante'].' €';
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Pré-Saldo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['pre_saldo'].' €';
                echo '</td>';
            echo '</tr>';
            echo '<tr>';
                echo '<td id="label" style="text-align:right">Pós-Saldo:</td>';
                echo '<td style="text-align: left">';
                    echo $row['pos_saldo'].' €';
                echo '</td>';
            echo '</tr>';
        echo '</table>';
    }
?>
