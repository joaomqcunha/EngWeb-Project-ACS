<div id="fheader">
    <div id="menubar">
        <?
        echo '<li><a href="index.php">'.$lang_topmenu0.'</a></li>';
        if (isset($_SESSION['user'])) {
            if($_SESSION['group'] == 0 || $_SESSION['group'] == 1) {
                echo '<li><a href="conta.php">'.$lang_topmenu1.'</a></li>';
                echo '<li><a href="consultas.php">'.$lang_topmenu2.'</a></li>';
                if($_SESSION['group'] == 0) {
                    echo '<li><a href="bar.php">'.$lang_topmenu3.'</a></li>';
                    echo '<li><a href="cantina.php">'.$lang_topmenu4.'</a></li>';
                }
                else {
                    echo '<li><a href="senhas.php">'.$lang_topmenu5.'</a></li>';
                    echo '<li><a href="carregamentos.php">'.$lang_topmenu6.'</a></li>';
                }
            }
            else echo '<li><a href="admin.php">'.$lang_topmenu7.'</a></li>';
        }
        ?>
    </div>
    <div id="lang">
        <li><a href="includes/lang.php?l=PT&p=index.php">PT</a></li>
        <li><a href="includes/lang.php?l=EN&p=index.php">EN</a></li>
    </div>
</div>
